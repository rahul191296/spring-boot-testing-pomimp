package com.cognizant.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import com.cognizant.daoImpl.AdminDaoImpl;
import com.cognizant.interfac.AdminDao;

import com.cognizant.model.AdminModel;
import com.cognizant.serviceImpl.AdminServiceImpl;



@RunWith(SpringRunner.class)
@SpringBootTest(classes = {AdminServiceImpl.class ,AdminDaoImpl.class})
@ComponentScan(basePackages = "com.cognizant.*")
@EntityScan(basePackages = "com.cognizant.entity")
public class TestAdminServiceImpl {
	private MockMvc mockMvc;
	
	@InjectMocks
	private AdminServiceImpl adminService;
	
	
	
	@Autowired
	@Spy
	private AdminDao adminDao;
	
	@Before
	public void init() {
	//	adminService = new AdminServiceImpl();
	//	adminDao = new AdminDaoImpl();
	//	adminConvertor = new AdminConvertor();
		
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(adminService).build();
	}

	
	@Test 
	public void testGetAdminLoginStatus() {

		AdminModel adminModel = new AdminModel();
		adminModel.setUserName("Rahul62@");
		adminModel.setPassword("rahul");

		boolean status = adminService.getAdminLoginStatus(adminModel);
		assertEquals(true, status);
	}

	@Test
	public void testBlockUser() {
		boolean res=adminService.blockUser(18);
		assertEquals(true,res);
	}

	@Test
	public void testUnBlockUser() {
		boolean res=adminService.UnblockUser(10);
		assertEquals(true,res);
	}

	@Test
	public void testBlockMentor() {
		boolean res=adminService.blockMentor(4);
		assertEquals(true,res);
	}

	@Test
	public void testUnBlockMentor() {
		boolean res=adminService.UnblockMentor(15);
		assertEquals(true,res);
	}

	@Test
	public void test() {
		int i=6500;
	String res=adminService.getBracket(i);
	assertEquals("medium",res);
	}
}
